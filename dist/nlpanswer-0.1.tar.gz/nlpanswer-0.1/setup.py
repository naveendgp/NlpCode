# Nlpanswer/setup.py

from setuptools import setup, find_packages

setup(
    name="Nlpanswer",
    version="0.1",
    description="A package for NLP solutions",
    author="Naveen sakth the great",
    author_email="naveendgp@gmail.com",
    packages=find_packages(),
    install_requires=[],  # Add required packages here
)
